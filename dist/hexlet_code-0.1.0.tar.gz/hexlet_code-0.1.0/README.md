### Hexlet tests and linter status:
[![Actions Status](https://github.com/Niki-name/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Niki-name/python-project-49/actions)
\n
#Ссылка на аккаунт Code_сlimate
<a href="https://codeclimate.com/github/Niki-name/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/72b95b373375ef2ff44b/maintainability" /></a>
\n
#Сслыка на игру на чётность
https://asciinema.org/a/553379
\n
#Ссылка на игру калькулятор
https://asciinema.org/a/553428
\n
#Ссылка на игру НОД
https://asciinema.org/a/553504
\n
#Ссылка на игру прогрессия
https://asciinema.org/a/553686
\n
#Сслыка на игру по простому числу
https://asciinema.org/a/553823
