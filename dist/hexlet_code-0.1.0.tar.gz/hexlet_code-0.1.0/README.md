### Hexlet tests and linter status:
[![Actions Status](https://github.com/Niki-name/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Niki-name/python-project-49/actions)
#Ссылка на аккаунт Code_сlimate
<a href="https://codeclimate.com/github/Niki-name/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/72b95b373375ef2ff44b/maintainability" /></a>
#Сслыка на игру на чётность
https://asciinema.org/a/553379
#Ссылка на игру калькулятор
https://asciinema.org/a/553428
